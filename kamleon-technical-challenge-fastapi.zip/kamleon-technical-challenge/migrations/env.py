from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine
from sqlalchemy import pool

from kamleon.config import get_settings
from kamleon.db import Base

# Importing the models registers their tables on `Base.metadata`.
from kamleon.devices import models as devices_models  # noqa: F401
from kamleon.identity import models as identity_models  # noqa: F401
from kamleon.ingestion import models as ingestion_models  # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name, disable_existing_loggers=False)

target_metadata = Base.metadata


def get_url() -> str:
    # Tests (and tooling) can point a migration run at another database programmatically
    # with `config.attributes["url"] = ...`; otherwise use the application's setting.
    return str(config.attributes.get("url") or get_settings().database_url)


def run_migrations_offline() -> None:
    context.configure(
        url=get_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = create_engine(get_url(), poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
